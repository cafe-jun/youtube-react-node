import "./styles.css";

const title = document.querySelector("#title");

const BACKGROUND_COLOR_HALF = "#904fad";
const BACKGROUND_COLOR_FULL = "#eebc12";
const BACKGROUND_COLOR_DEFAULT = "#2d8dd6";

function browerResize() {
  const widthSize = window.innerWidth;
  console.log(widthSize);
  if (widthSize < 450) {
    document.body.style.backgroundColor = BACKGROUND_COLOR_DEFAULT;
  } else if (widthSize > 450 && widthSize < 800) {
    document.body.style.backgroundColor = BACKGROUND_COLOR_HALF;
  } else {
    document.body.style.backgroundColor = BACKGROUND_COLOR_FULL;
  }
}

function init() {
  title.style.color = "white";
  document.body.style.backgroundColor = BACKGROUND_COLOR_DEFAULT;
}

window.addEventListener("resize", browerResize);
init();
